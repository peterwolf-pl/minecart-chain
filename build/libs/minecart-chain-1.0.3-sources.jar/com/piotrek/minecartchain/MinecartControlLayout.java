package com.piotrek.minecartchain;

import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

public final class MinecartControlLayout {
	public static final double REAR_CONTROL_X = 0.68D;
	public static final double BRAKE_CONTROL_Z = 0.38D;
	public static final double THROTTLE_CONTROL_Z = -0.38D;

	private static final double CONTROL_HIT_X_RADIUS = 0.42D;
	private static final double CONTROL_HIT_Z_RADIUS = 0.24D;
	private static final double CONTROL_HIT_Y_MIN = 0.05D;
	private static final double CONTROL_HIT_Y_MAX = 1.1D;

	private MinecartControlLayout() {
	}

	public static Control hitControl(final AbstractMinecart minecart, final Player player, final EntityHitResult hitResult) {
		Vec3 forward = forwardDirection(minecart);
		if (forward.lengthSqr() <= 1.0E-5D) {
			return Control.NONE;
		}
		Vec3 right = new Vec3(-forward.z, 0.0D, forward.x).normalize();

		if (hitResult != null) {
			Control pointControl = controlAtLocalPoint(toLocal(hitResult.getLocation().subtract(minecart.position()), forward, right));
			if (pointControl != Control.NONE) {
				return pointControl;
			}
		}

		return rayControl(minecart, player, forward, right);
	}

	private static Control controlAtLocalPoint(final Vec3 localPoint) {
		if (localPoint.y < CONTROL_HIT_Y_MIN || localPoint.y > CONTROL_HIT_Y_MAX) {
			return Control.NONE;
		}
		if (Math.abs(Math.abs(localPoint.x) - REAR_CONTROL_X) > CONTROL_HIT_X_RADIUS) {
			return Control.NONE;
		}
		return controlAtLocalZ(localPoint.z);
	}

	private static Control rayControl(final AbstractMinecart minecart, final Player player, final Vec3 forward, final Vec3 right) {
		Vec3 localOrigin = toLocal(player.getEyePosition().subtract(minecart.position()), forward, right);
		Vec3 localDirection = toLocal(player.getViewVector(1.0F).normalize(), forward, right);
		double reach = Math.max(5.0D, player.entityInteractionRange() + 1.0D);
		Vec3 localEnd = localOrigin.add(localDirection.scale(reach));

		double brakeDistance = nearestPanelHitDistance(localOrigin, localEnd, BRAKE_CONTROL_Z);
		double throttleDistance = nearestPanelHitDistance(localOrigin, localEnd, THROTTLE_CONTROL_Z);
		if (!Double.isFinite(brakeDistance) && !Double.isFinite(throttleDistance)) {
			return Control.NONE;
		}
		return brakeDistance <= throttleDistance ? Control.BRAKE : Control.THROTTLE;
	}

	private static double nearestPanelHitDistance(final Vec3 localOrigin, final Vec3 localEnd, final double localZ) {
		double rearHit = hitDistance(panelBox(REAR_CONTROL_X, localZ), localOrigin, localEnd);
		double mirroredHit = hitDistance(panelBox(-REAR_CONTROL_X, localZ), localOrigin, localEnd);
		return Math.min(rearHit, mirroredHit);
	}

	private static double hitDistance(final AABB box, final Vec3 localOrigin, final Vec3 localEnd) {
		return box.clip(localOrigin, localEnd)
			.map(localOrigin::distanceToSqr)
			.orElse(Double.POSITIVE_INFINITY);
	}

	private static AABB panelBox(final double localX, final double localZ) {
		return new AABB(
			localX - CONTROL_HIT_X_RADIUS,
			CONTROL_HIT_Y_MIN,
			localZ - CONTROL_HIT_Z_RADIUS,
			localX + CONTROL_HIT_X_RADIUS,
			CONTROL_HIT_Y_MAX,
			localZ + CONTROL_HIT_Z_RADIUS
		);
	}

	private static Control controlAtLocalZ(final double localZ) {
		if (Math.abs(localZ - BRAKE_CONTROL_Z) <= CONTROL_HIT_Z_RADIUS) {
			return Control.BRAKE;
		}
		if (Math.abs(localZ - THROTTLE_CONTROL_Z) <= CONTROL_HIT_Z_RADIUS) {
			return Control.THROTTLE;
		}
		return Control.NONE;
	}

	private static Vec3 toLocal(final Vec3 offset, final Vec3 forward, final Vec3 right) {
		return new Vec3(offset.dot(forward), offset.y, -offset.dot(right));
	}

	private static Vec3 forwardDirection(final AbstractMinecart minecart) {
		MinecartChainAccess data = (MinecartChainAccess) minecart;
		if (data.minecartChain$hasLocomotiveYaw()) {
			return MinecartTrainLogic.directionFromYaw(data.minecartChain$getLocomotiveYaw());
		}

		Vec3 forward = new Vec3(minecart.getMotionDirection().getStepX(), 0.0D, minecart.getMotionDirection().getStepZ());
		if (forward.lengthSqr() > 1.0E-5D) {
			return forward.normalize();
		}

		double yaw = Math.toRadians(minecart.getYRot());
		return new Vec3(-Math.sin(yaw), 0.0D, Math.cos(yaw));
	}

	public enum Control {
		NONE,
		BRAKE,
		THROTTLE
	}
}
