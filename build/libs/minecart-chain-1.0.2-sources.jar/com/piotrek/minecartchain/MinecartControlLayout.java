package com.piotrek.minecartchain;

import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

public final class MinecartControlLayout {
	public static final double REAR_CONTROL_X = 0.68D;
	public static final double BRAKE_CONTROL_Z = 0.38D;
	public static final double THROTTLE_CONTROL_Z = -0.38D;

	private static final double CONTROL_HIT_X_RADIUS = 0.34D;
	private static final double CONTROL_HIT_Z_RADIUS = 0.24D;
	private static final double CONTROL_HIT_Y_MIN = 0.2D;
	private static final double CONTROL_HIT_Y_MAX = 0.95D;

	private MinecartControlLayout() {
	}

	public static Control hitControl(final AbstractMinecart minecart, final EntityHitResult hitResult) {
		if (hitResult == null) {
			return Control.NONE;
		}

		Vec3 hitOffset = hitResult.getLocation().subtract(minecart.position());
		if (hitOffset.y < CONTROL_HIT_Y_MIN || hitOffset.y > CONTROL_HIT_Y_MAX) {
			return Control.NONE;
		}

		Vec3 horizontalHit = hitOffset.horizontal();
		if (horizontalHit.lengthSqr() <= 1.0E-5D) {
			return Control.NONE;
		}

		Vec3 forward = forwardDirection(minecart);
		if (forward.lengthSqr() <= 1.0E-5D) {
			return Control.NONE;
		}

		Vec3 right = new Vec3(-forward.z, 0.0D, forward.x).normalize();
		double localX = horizontalHit.dot(forward);
		if (Math.abs(localX - REAR_CONTROL_X) > CONTROL_HIT_X_RADIUS) {
			return Control.NONE;
		}

		double localZ = horizontalHit.dot(right);
		if (Math.abs(localZ - BRAKE_CONTROL_Z) <= CONTROL_HIT_Z_RADIUS) {
			return Control.BRAKE;
		}
		if (Math.abs(localZ - THROTTLE_CONTROL_Z) <= CONTROL_HIT_Z_RADIUS) {
			return Control.THROTTLE;
		}
		return Control.NONE;
	}

	private static Vec3 forwardDirection(final AbstractMinecart minecart) {
		MinecartChainAccess data = (MinecartChainAccess) minecart;
		if (data.minecartChain$hasLocomotiveYaw()) {
			return MinecartTrainLogic.directionFromYaw(data.minecartChain$getLocomotiveYaw());
		}

		Vec3 forward = new Vec3(minecart.getMotionDirection().getStepX(), 0.0D, minecart.getMotionDirection().getStepZ());
		if (forward.lengthSqr() > 1.0E-5D) {
			return forward.normalize();
		}

		double yaw = Math.toRadians(minecart.getYRot());
		return new Vec3(-Math.sin(yaw), 0.0D, Math.cos(yaw));
	}

	public enum Control {
		NONE,
		BRAKE,
		THROTTLE
	}
}
