package com.piotrek.minecartchain;

import java.util.Optional;
import java.util.UUID;

public interface MinecartChainAccess {
	Optional<UUID> minecartChain$getFirstLink();

	Optional<UUID> minecartChain$getSecondLink();

	boolean minecartChain$addLink(UUID uuid);

	void minecartChain$removeLink(UUID uuid);

	void minecartChain$clearLinks();

	boolean minecartChain$hasEngineLever();

	void minecartChain$setEngineLever(boolean mounted);

	boolean minecartChain$isEngineActive();

	void minecartChain$setEngineActive(boolean active);

	boolean minecartChain$isFullThrottle();

	void minecartChain$setFullThrottle(boolean fullThrottle);

	boolean minecartChain$hasLocomotiveYaw();

	void minecartChain$setHasLocomotiveYaw(boolean hasLocomotiveYaw);

	float minecartChain$getLocomotiveYaw();

	void minecartChain$setLocomotiveYaw(float yaw);

	default boolean minecartChain$hasLink(final UUID uuid) {
		return this.minecartChain$getFirstLink().filter(uuid::equals).isPresent()
			|| this.minecartChain$getSecondLink().filter(uuid::equals).isPresent();
	}

	default boolean minecartChain$canAcceptLink() {
		return this.minecartChain$getFirstLink().isEmpty() || this.minecartChain$getSecondLink().isEmpty();
	}

	default int minecartChain$linkCount() {
		int count = 0;
		if (this.minecartChain$getFirstLink().isPresent()) {
			count++;
		}
		if (this.minecartChain$getSecondLink().isPresent()) {
			count++;
		}
		return count;
	}
}
