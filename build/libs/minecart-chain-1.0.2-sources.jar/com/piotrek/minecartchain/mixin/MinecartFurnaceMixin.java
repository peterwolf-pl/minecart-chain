package com.piotrek.minecartchain.mixin;

import com.piotrek.minecartchain.MinecartChainAccess;
import com.piotrek.minecartchain.MinecartTrainLogic;
import net.minecraft.world.entity.vehicle.minecart.MinecartFurnace;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecartFurnace.class)
public abstract class MinecartFurnaceMixin {
	@Shadow
	public Vec3 push;

	@Shadow
	protected abstract void setHasFuel(boolean hasFuel);

	@Inject(method = "tick", at = @At("TAIL"))
	private void minecartChain$tickEngine(final CallbackInfo ci) {
		MinecartFurnace furnace = (MinecartFurnace) (Object) this;
		MinecartChainAccess data = (MinecartChainAccess) furnace;
		if (furnace.level().isClientSide() || !data.minecartChain$hasEngineLever()) {
			return;
		}

		Vec3 direction = MinecartTrainLogic.engineDirection(furnace);
		MinecartTrainLogic.updateLocomotiveYaw(furnace, direction);

		if (data.minecartChain$isEngineActive()) {
			this.push = Vec3.ZERO;
			MinecartTrainLogic.applyTrainBrake(furnace);
			this.setHasFuel(false);
			return;
		}

		boolean fullThrottle = data.minecartChain$isFullThrottle();
		this.push = MinecartTrainLogic.enginePushVector(direction, fullThrottle);
		MinecartTrainLogic.applyEngineAssist(furnace, direction, fullThrottle);
		MinecartTrainLogic.guidePoweredTrain(furnace, direction);
		this.setHasFuel(true);
	}
}
