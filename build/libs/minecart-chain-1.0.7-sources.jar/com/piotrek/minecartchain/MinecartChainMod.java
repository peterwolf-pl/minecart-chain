package com.piotrek.minecartchain;

import net.fabricmc.api.ModInitializer;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.flag.FeatureFlags;
import net.minecraft.world.inventory.MenuType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MinecartChainMod implements ModInitializer {
	public static final String MOD_ID = "minecart_chain";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
	public static final MenuType<MinecartLocomotiveMenu> LOCOMOTIVE_MENU = Registry.register(
		BuiltInRegistries.MENU,
		id("locomotive"),
		new MenuType<>(MinecartLocomotiveMenu::new, FeatureFlags.VANILLA_SET)
	);

	@Override
	public void onInitialize() {
		MinecartLinkHandler.register();
		LOGGER.info("Registered minecart chain interactions");
	}

	public static Identifier id(final String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
