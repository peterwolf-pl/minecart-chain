package com.piotrek.minecartchain.client;

import java.util.List;
import net.minecraft.client.renderer.block.BlockModelRenderState;
import net.minecraft.world.phys.Vec3;

public interface MinecartChainRenderState {
	BlockModelRenderState minecartChain$leverModel();

	BlockModelRenderState minecartChain$chainXModel();

	BlockModelRenderState minecartChain$chainZModel();

	boolean minecartChain$hasLever();

	void minecartChain$setHasLever(boolean hasLever);

	List<Vec3> minecartChain$chainOffsets();

	void minecartChain$clearChainOffsets();
}
