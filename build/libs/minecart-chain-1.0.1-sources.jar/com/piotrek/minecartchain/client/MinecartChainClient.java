package com.piotrek.minecartchain.client;

import com.piotrek.minecartchain.MinecartChainMod;
import net.fabricmc.api.ClientModInitializer;

public class MinecartChainClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		MinecartChainMod.LOGGER.info("Minecart chain client renderer hooks loaded");
	}
}
