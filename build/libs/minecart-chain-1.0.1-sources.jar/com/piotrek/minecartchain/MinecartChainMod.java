package com.piotrek.minecartchain;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MinecartChainMod implements ModInitializer {
	public static final String MOD_ID = "minecart_chain";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		MinecartLinkHandler.register();
		LOGGER.info("Registered minecart chain interactions");
	}

	public static Identifier id(final String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
