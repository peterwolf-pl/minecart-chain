package com.piotrek.minecartchain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import net.minecraft.world.entity.vehicle.minecart.MinecartFurnace;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public final class MinecartLinkHandler {
	private static final double MAX_LINK_DISTANCE = 2.5D;
	private static final Map<UUID, UUID> SELECTED_CARTS = new HashMap<>();

	private MinecartLinkHandler() {
	}

	public static void register() {
		UseEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
			if (!(entity instanceof AbstractMinecart minecart)) {
				return InteractionResult.PASS;
			}

			ItemStack stack = player.getItemInHand(hand);
			if (stack.getItem() == Items.IRON_CHAIN) {
				if (!level.isClientSide()) {
					handleChainUse(player, level, hand, minecart, stack);
				}
				return InteractionResult.SUCCESS;
			}

			if (minecart instanceof MinecartFurnace && canUseAsEngineLever(minecart, stack)) {
				if (!level.isClientSide()) {
					handleLeverUse(player, level, minecart, stack);
				}
				return InteractionResult.SUCCESS;
			}

			return InteractionResult.PASS;
		});
	}

	private static boolean canUseAsEngineLever(final AbstractMinecart minecart, final ItemStack stack) {
		return stack.getItem() == Items.LEVER || (stack.isEmpty() && ((MinecartChainAccess) minecart).minecartChain$hasEngineLever());
	}

	private static void handleChainUse(
		final Player player, final Level level, final InteractionHand hand, final AbstractMinecart minecart, final ItemStack stack
	) {
		if (!(player instanceof ServerPlayer serverPlayer) || !(level instanceof ServerLevel serverLevel)) {
			return;
		}

		if (player.isSecondaryUseActive()) {
			unlinkAll(serverPlayer, serverLevel, minecart);
			return;
		}

		MinecartChainAccess currentData = (MinecartChainAccess) minecart;
		if (!currentData.minecartChain$canAcceptLink()) {
			send(serverPlayer, "This minecart already has two links.");
			return;
		}

		UUID playerId = serverPlayer.getUUID();
		UUID selectedId = SELECTED_CARTS.get(playerId);
		if (selectedId == null) {
			SELECTED_CARTS.put(playerId, minecart.getUUID());
			play(level, minecart, SoundEvents.CHAIN_HIT, 0.85F, 1.1F);
			send(serverPlayer, "First minecart selected. Click another minecart with iron chain to link them.");
			return;
		}

		if (selectedId.equals(minecart.getUUID())) {
			SELECTED_CARTS.remove(playerId);
			play(level, minecart, SoundEvents.CHAIN_HIT, 0.65F, 0.8F);
			send(serverPlayer, "Minecart selection cancelled.");
			return;
		}

		Entity selectedEntity = serverLevel.getEntity(selectedId);
		if (!(selectedEntity instanceof AbstractMinecart selectedMinecart)) {
			SELECTED_CARTS.remove(playerId);
			send(serverPlayer, "The first minecart is no longer loaded. Select it again.");
			return;
		}

		MinecartChainAccess selectedData = (MinecartChainAccess) selectedMinecart;
		if (!selectedData.minecartChain$canAcceptLink()) {
			SELECTED_CARTS.remove(playerId);
			send(serverPlayer, "The first minecart already has two links.");
			return;
		}

		if (selectedData.minecartChain$hasLink(minecart.getUUID())) {
			SELECTED_CARTS.remove(playerId);
			send(serverPlayer, "These minecarts are already linked.");
			return;
		}

		if (selectedMinecart.distanceToSqr(minecart) > MAX_LINK_DISTANCE * MAX_LINK_DISTANCE) {
			SELECTED_CARTS.remove(playerId);
			send(serverPlayer, "Minecarts must be at most 2.5 blocks apart.");
			return;
		}

		selectedData.minecartChain$addLink(minecart.getUUID());
		currentData.minecartChain$addLink(selectedMinecart.getUUID());
		boolean mountedLever = mountEngineLeverIfNeeded(level, selectedMinecart) | mountEngineLeverIfNeeded(level, minecart);
		SELECTED_CARTS.remove(playerId);
		if (!serverPlayer.hasInfiniteMaterials()) {
			stack.consume(1, serverPlayer);
		}

		play(level, minecart, SoundEvents.CHAIN_PLACE, 1.0F, 1.0F);
		send(serverPlayer, mountedLever ? "Minecarts linked. A brake lever appeared on the furnace minecart. Brake engaged." : "Minecarts linked with a chain.");
	}

	private static boolean mountEngineLeverIfNeeded(final Level level, final AbstractMinecart minecart) {
		if (!(minecart instanceof MinecartFurnace)) {
			return false;
		}

		MinecartChainAccess data = (MinecartChainAccess) minecart;
		if (data.minecartChain$hasEngineLever()) {
			return false;
		}

		data.minecartChain$setEngineLever(true);
		data.minecartChain$setEngineActive(true);
		play(level, minecart, SoundEvents.LEVER_CLICK, 0.9F, 0.5F);
		return true;
	}

	private static void handleLeverUse(final Player player, final Level level, final AbstractMinecart minecart, final ItemStack stack) {
		if (!(player instanceof ServerPlayer serverPlayer)) {
			return;
		}

		MinecartChainAccess data = (MinecartChainAccess) minecart;
		if (!data.minecartChain$hasEngineLever()) {
			data.minecartChain$setEngineLever(true);
			data.minecartChain$setEngineActive(false);
			if (!serverPlayer.hasInfiniteMaterials()) {
				stack.consume(1, serverPlayer);
			}
			play(level, minecart, SoundEvents.LEVER_CLICK, 0.9F, 0.6F);
			send(serverPlayer, "Mounted a brake lever on the furnace minecart. Brake released.");
			return;
		}

		boolean brake = !data.minecartChain$isEngineActive();
		data.minecartChain$setEngineActive(brake);
		play(level, minecart, SoundEvents.LEVER_CLICK, 0.9F, brake ? 0.5F : 0.6F);
		send(serverPlayer, brake ? "Brake engaged." : "Brake released.");
	}

	private static void unlinkAll(final ServerPlayer player, final ServerLevel level, final AbstractMinecart minecart) {
		MinecartChainAccess data = (MinecartChainAccess) minecart;
		List<UUID> links = linkedIds(data);
		if (links.isEmpty()) {
			SELECTED_CARTS.remove(player.getUUID());
			send(player, "This minecart has no links.");
			return;
		}

		for (UUID linkId : links) {
			Entity linkedEntity = level.getEntity(linkId);
			if (linkedEntity instanceof AbstractMinecart linkedMinecart) {
				((MinecartChainAccess) linkedMinecart).minecartChain$removeLink(minecart.getUUID());
			}
		}
		data.minecartChain$clearLinks();
		SELECTED_CARTS.remove(player.getUUID());
		play(level, minecart, SoundEvents.CHAIN_BREAK, 1.0F, 0.9F);
		send(player, "Removed this minecart's chain links.");
	}

	private static List<UUID> linkedIds(final MinecartChainAccess data) {
		List<UUID> links = new ArrayList<>(2);
		data.minecartChain$getFirstLink().ifPresent(links::add);
		data.minecartChain$getSecondLink().ifPresent(links::add);
		return links;
	}

	private static void play(final Level level, final AbstractMinecart minecart, final net.minecraft.sounds.SoundEvent sound, final float volume, final float pitch) {
		level.playSound(null, minecart.getX(), minecart.getY(), minecart.getZ(), sound, SoundSource.BLOCKS, volume, pitch);
	}

	private static void send(final ServerPlayer player, final String message) {
		player.sendSystemMessage(Component.literal(message));
	}
}
