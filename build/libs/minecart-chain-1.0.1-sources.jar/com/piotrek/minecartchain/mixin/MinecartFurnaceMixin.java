package com.piotrek.minecartchain.mixin;

import com.piotrek.minecartchain.MinecartChainAccess;
import com.piotrek.minecartchain.MinecartTrainLogic;
import net.minecraft.world.entity.vehicle.minecart.MinecartFurnace;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecartFurnace.class)
public abstract class MinecartFurnaceMixin {
	@Shadow
	public Vec3 push;

	@Shadow
	protected abstract void setHasFuel(boolean hasFuel);

	@Inject(method = "tick", at = @At("TAIL"))
	private void minecartChain$tickEngine(final CallbackInfo ci) {
		MinecartFurnace furnace = (MinecartFurnace) (Object) this;
		MinecartChainAccess data = (MinecartChainAccess) furnace;
		if (furnace.level().isClientSide() || !data.minecartChain$hasEngineLever()) {
			return;
		}

		if (data.minecartChain$isEngineActive()) {
			this.push = Vec3.ZERO;
			MinecartTrainLogic.applyTrainBrake(furnace);
			this.setHasFuel(false);
			return;
		}

		Vec3 direction = MinecartTrainLogic.engineDirection(furnace);
		this.push = MinecartTrainLogic.enginePushVector(direction);
		MinecartTrainLogic.applyEngineAssist(furnace, direction);
		MinecartTrainLogic.guidePoweredTrain(furnace, direction);
		this.setHasFuel(true);
	}
}
