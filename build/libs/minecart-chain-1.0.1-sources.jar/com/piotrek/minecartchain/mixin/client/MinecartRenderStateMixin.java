package com.piotrek.minecartchain.mixin.client;

import com.piotrek.minecartchain.client.MinecartChainRenderState;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.renderer.block.BlockModelRenderState;
import net.minecraft.client.renderer.entity.state.MinecartRenderState;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(MinecartRenderState.class)
public abstract class MinecartRenderStateMixin implements MinecartChainRenderState {
	@Unique
	private final BlockModelRenderState minecartChain$leverModel = new BlockModelRenderState();
	@Unique
	private final BlockModelRenderState minecartChain$chainXModel = new BlockModelRenderState();
	@Unique
	private final BlockModelRenderState minecartChain$chainZModel = new BlockModelRenderState();
	@Unique
	private final List<Vec3> minecartChain$chainOffsets = new ArrayList<>(2);
	@Unique
	private boolean minecartChain$hasLever;

	@Override
	public BlockModelRenderState minecartChain$leverModel() {
		return this.minecartChain$leverModel;
	}

	@Override
	public BlockModelRenderState minecartChain$chainXModel() {
		return this.minecartChain$chainXModel;
	}

	@Override
	public BlockModelRenderState minecartChain$chainZModel() {
		return this.minecartChain$chainZModel;
	}

	@Override
	public boolean minecartChain$hasLever() {
		return this.minecartChain$hasLever;
	}

	@Override
	public void minecartChain$setHasLever(final boolean hasLever) {
		this.minecartChain$hasLever = hasLever;
	}

	@Override
	public List<Vec3> minecartChain$chainOffsets() {
		return this.minecartChain$chainOffsets;
	}

	@Override
	public void minecartChain$clearChainOffsets() {
		this.minecartChain$chainOffsets.clear();
	}
}
