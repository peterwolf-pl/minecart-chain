package com.piotrek.minecartchain.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.piotrek.minecartchain.MinecartChainAccess;
import com.piotrek.minecartchain.client.MinecartChainRenderState;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.block.BlockModelRenderState;
import net.minecraft.client.renderer.block.BlockModelResolver;
import net.minecraft.client.renderer.entity.AbstractMinecartRenderer;
import net.minecraft.client.renderer.entity.state.MinecartRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import net.minecraft.world.entity.vehicle.minecart.MinecartFurnace;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FaceAttachedHorizontalDirectionalBlock;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.LeverBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractMinecartRenderer.class)
public abstract class AbstractMinecartRendererMixin<T extends AbstractMinecart, S extends MinecartRenderState> {
	private static final double CHAIN_ATTACHMENT_OFFSET = 0.62D;
	private static final double CHAIN_HEIGHT = 0.38D;
	private static final double CHAIN_SEGMENT_SPACING = 0.42D;
	private static final float CHAIN_SEGMENT_SCALE = 0.46F;

	@Shadow
	@Final
	private BlockModelResolver blockModelResolver;

	@Inject(method = "extractRenderState(Lnet/minecraft/world/entity/vehicle/minecart/AbstractMinecart;Lnet/minecraft/client/renderer/entity/state/MinecartRenderState;F)V", at = @At("TAIL"))
	private void minecartChain$extractRenderState(final T minecart, final S state, final float tickProgress, final CallbackInfo ci) {
		MinecartChainRenderState chainState = (MinecartChainRenderState) state;
		MinecartChainAccess data = (MinecartChainAccess) minecart;
		chainState.minecartChain$clearChainOffsets();
		this.minecartChain$appendChainOffset(minecart, chainState, data.minecartChain$getFirstLink(), tickProgress);
		this.minecartChain$appendChainOffset(minecart, chainState, data.minecartChain$getSecondLink(), tickProgress);
		this.blockModelResolver.update(chainState.minecartChain$chainXModel(), chainBlock(Direction.Axis.X), AbstractMinecartRenderer.BLOCK_DISPLAY_CONTEXT);
		this.blockModelResolver.update(chainState.minecartChain$chainZModel(), chainBlock(Direction.Axis.Z), AbstractMinecartRenderer.BLOCK_DISPLAY_CONTEXT);

		boolean hasLever = minecart instanceof MinecartFurnace && ((MinecartChainAccess) minecart).minecartChain$hasEngineLever();
		chainState.minecartChain$setHasLever(hasLever);
		if (!hasLever) {
			chainState.minecartChain$leverModel().clear();
			return;
		}

		boolean powered = ((MinecartChainAccess) minecart).minecartChain$isEngineActive();
		BlockState leverState = Blocks.LEVER.defaultBlockState()
			.setValue(FaceAttachedHorizontalDirectionalBlock.FACE, AttachFace.FLOOR)
			.setValue(HorizontalDirectionalBlock.FACING, Direction.NORTH)
			.setValue(LeverBlock.POWERED, powered);
		this.blockModelResolver.update(chainState.minecartChain$leverModel(), leverState, AbstractMinecartRenderer.BLOCK_DISPLAY_CONTEXT);
	}

	@Inject(
		method = "submit(Lnet/minecraft/client/renderer/entity/state/MinecartRenderState;Lcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/renderer/state/level/CameraRenderState;)V",
		at = @At("HEAD")
	)
	private void minecartChain$submitChains(
		final S state,
		final PoseStack poseStack,
		final SubmitNodeCollector submitNodeCollector,
		final CameraRenderState cameraRenderState,
		final CallbackInfo ci
	) {
		MinecartChainRenderState chainState = (MinecartChainRenderState) state;
		for (Vec3 offset : chainState.minecartChain$chainOffsets()) {
			this.minecartChain$submitChain(offset, chainState, poseStack, submitNodeCollector, state.lightCoords, state.outlineColor);
		}
	}

	@Inject(method = "submitMinecartContents", at = @At("TAIL"))
	private void minecartChain$submitLever(
		final S state,
		final BlockModelRenderState displayBlock,
		final PoseStack poseStack,
		final SubmitNodeCollector submitNodeCollector,
		final int lightCoords,
		final CallbackInfo ci
	) {
		MinecartChainRenderState chainState = (MinecartChainRenderState) state;
		if (!chainState.minecartChain$hasLever() || chainState.minecartChain$leverModel().isEmpty()) {
			return;
		}

		poseStack.pushPose();
		poseStack.translate(0.0F, 1.0F, 0.0F);
		chainState.minecartChain$leverModel()
			.submit(poseStack, submitNodeCollector, lightCoords, OverlayTexture.NO_OVERLAY, state.outlineColor);
		poseStack.popPose();
	}

	private void minecartChain$appendChainOffset(
		final AbstractMinecart minecart,
		final MinecartChainRenderState chainState,
		final Optional<UUID> linkedId,
		final float tickProgress
	) {
		if (linkedId.isEmpty() || minecart.getUUID().compareTo(linkedId.get()) >= 0) {
			return;
		}

		Entity linkedEntity = minecart.level().getEntity(linkedId.get());
		if (!(linkedEntity instanceof AbstractMinecart linkedMinecart)) {
			return;
		}

		Vec3 offset = linkedMinecart.getPosition(tickProgress).subtract(minecart.getPosition(tickProgress));
		if (offset.horizontalDistanceSqr() <= 0.25D || offset.lengthSqr() > 144.0D) {
			return;
		}

		chainState.minecartChain$chainOffsets().add(offset);
	}

	private void minecartChain$submitChain(
		final Vec3 offset,
		final MinecartChainRenderState chainState,
		final PoseStack poseStack,
		final SubmitNodeCollector submitNodeCollector,
		final int lightCoords,
		final int outlineColor
	) {
		double length = offset.length();
		double visibleLength = length - CHAIN_ATTACHMENT_OFFSET * 2.0D;
		if (visibleLength <= 0.1D) {
			return;
		}

		Vec3 direction = offset.scale(1.0D / length);
		int segments = Math.max(1, (int) Math.ceil(visibleLength / CHAIN_SEGMENT_SPACING));
		double step = visibleLength / segments;
		BlockModelRenderState chainModel = Math.abs(offset.x) >= Math.abs(offset.z)
			? chainState.minecartChain$chainXModel()
			: chainState.minecartChain$chainZModel();

		for (int i = 0; i < segments; i++) {
			double distance = CHAIN_ATTACHMENT_OFFSET + (i + 0.5D) * step;
			Vec3 position = direction.scale(distance).add(0.0D, CHAIN_HEIGHT, 0.0D);
			poseStack.pushPose();
			poseStack.translate(position.x, position.y, position.z);
			poseStack.scale(CHAIN_SEGMENT_SCALE, CHAIN_SEGMENT_SCALE, CHAIN_SEGMENT_SCALE);
			poseStack.translate(-0.5F, -0.5F, -0.5F);
			chainModel.submit(poseStack, submitNodeCollector, lightCoords, OverlayTexture.NO_OVERLAY, outlineColor);
			poseStack.popPose();
		}
	}

	private static BlockState chainBlock(final Direction.Axis axis) {
		return Blocks.IRON_CHAIN.defaultBlockState().setValue(RotatedPillarBlock.AXIS, axis);
	}
}
