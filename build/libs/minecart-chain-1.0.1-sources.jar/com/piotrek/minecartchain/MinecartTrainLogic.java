package com.piotrek.minecartchain;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import net.minecraft.world.entity.vehicle.minecart.MinecartFurnace;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseRailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.RailShape;
import net.minecraft.world.phys.Vec3;

public final class MinecartTrainLogic {
	private static final double LINK_DISTANCE = 2.5D;
	private static final double MAX_LINK_DISTANCE = 2.65D;
	private static final double MIN_LINK_DISTANCE = 2.05D;
	private static final double LINK_BREAK_DISTANCE = 12.0D;
	private static final double LINK_STIFFNESS = 0.1D;
	private static final double MIN_DISTANCE_PUSH = 0.12D;
	private static final double MAX_LINK_IMPULSE = 0.14D;
	private static final double ENGINE_PUSH = 0.06D;
	private static final double ENGINE_ASSIST = 0.03D;
	private static final double MAX_ENGINE_SPEED = 0.55D;
	private static final double FOLLOWER_VELOCITY_BLEND = 0.52D;
	private static final double FOLLOWER_PULL = 0.11D;
	private static final double FOLLOWER_OVERTAKE_BRAKE = 0.52D;
	private static final double MAX_FOLLOWER_SPEED = 0.55D;
	private static final double BRAKE_DAMPING = 0.28D;
	private static final int MAX_TRAIN_LENGTH = 32;

	private MinecartTrainLogic() {
	}

	public static void tickLinks(final AbstractMinecart minecart) {
		Level level = minecart.level();
		if (level.isClientSide() || !(level instanceof ServerLevel serverLevel)) {
			return;
		}

		MinecartChainAccess data = (MinecartChainAccess) minecart;
		for (AbstractMinecart linked : linkedMinecarts(serverLevel, data)) {
			if (minecart.getUUID().compareTo(linked.getUUID()) < 0) {
				applyLinkConstraint(minecart, linked);
			}
		}
	}

	public static Vec3 engineDirection(final MinecartFurnace furnace) {
		Level level = furnace.level();
		if (level instanceof ServerLevel serverLevel) {
			Optional<AbstractMinecart> closestLinked = linkedMinecarts(serverLevel, (MinecartChainAccess) furnace).stream()
				.min(Comparator.comparingDouble(furnace::distanceToSqr));
			if (closestLinked.isPresent()) {
				Vec3 awayFromLinkedCart = furnace.position().subtract(closestLinked.get().position()).horizontal();
				if (awayFromLinkedCart.lengthSqr() > 1.0E-5D) {
					return awayFromLinkedCart.normalize();
				}
			}
		}

		Vec3 movement = furnace.getDeltaMovement().horizontal();
		if (movement.lengthSqr() > 1.0E-4D) {
			return movement.normalize();
		}

		Direction direction = furnace.getMotionDirection();
		Vec3 fallback = new Vec3(direction.getStepX(), 0.0D, direction.getStepZ());
		return fallback.lengthSqr() > 0.0D ? fallback.normalize() : Vec3.ZERO;
	}

	public static void applyEngineAssist(final MinecartFurnace furnace, final Vec3 direction) {
		if (direction.lengthSqr() <= 1.0E-5D) {
			return;
		}

		Vec3 horizontal = furnace.getDeltaMovement().horizontal().add(direction.scale(ENGINE_ASSIST));
		double speed = horizontal.length();
		if (speed > MAX_ENGINE_SPEED) {
			horizontal = horizontal.normalize().scale(MAX_ENGINE_SPEED);
		}

		Vec3 current = furnace.getDeltaMovement();
		furnace.setDeltaMovement(horizontal.x, current.y, horizontal.z);
	}

	public static void guidePoweredTrain(final MinecartFurnace furnace, final Vec3 engineDirection) {
		if (!(furnace.level() instanceof ServerLevel serverLevel)) {
			return;
		}

		List<AbstractMinecart> train = orderedTrain(serverLevel, furnace);
		if (train.size() < 2) {
			return;
		}

		Vec3 fallbackDirection = engineDirection.lengthSqr() > 1.0E-5D ? engineDirection.normalize() : Vec3.ZERO;
		for (int i = 1; i < train.size(); i++) {
			guideFollower(train.get(i - 1), train.get(i), fallbackDirection);
		}
	}

	public static void applyTrainBrake(final MinecartFurnace furnace) {
		if (!(furnace.level() instanceof ServerLevel serverLevel)) {
			return;
		}

		for (AbstractMinecart minecart : orderedTrain(serverLevel, furnace)) {
			Vec3 current = minecart.getDeltaMovement();
			minecart.setDeltaMovement(current.x * BRAKE_DAMPING, current.y, current.z * BRAKE_DAMPING);
		}
	}

	public static Vec3 enginePushVector(final Vec3 direction) {
		if (direction.lengthSqr() <= 1.0E-5D) {
			return Vec3.ZERO;
		}

		Vec3 normalized = direction.normalize();
		return new Vec3(normalized.x * ENGINE_PUSH, 0.0D, normalized.z * ENGINE_PUSH);
	}

	private static List<AbstractMinecart> linkedMinecarts(final ServerLevel level, final MinecartChainAccess data) {
		List<AbstractMinecart> minecarts = new ArrayList<>(2);
		addLinkedMinecart(level, data.minecartChain$getFirstLink(), minecarts);
		addLinkedMinecart(level, data.minecartChain$getSecondLink(), minecarts);
		return minecarts;
	}

	private static void addLinkedMinecart(final ServerLevel level, final Optional<UUID> linkId, final List<AbstractMinecart> minecarts) {
		if (linkId.isEmpty()) {
			return;
		}

		Entity entity = level.getEntity(linkId.get());
		if (entity instanceof AbstractMinecart minecart) {
			minecarts.add(minecart);
		}
	}

	private static List<AbstractMinecart> orderedTrain(final ServerLevel level, final AbstractMinecart engine) {
		List<AbstractMinecart> train = new ArrayList<>();
		Set<UUID> seen = new HashSet<>();
		AbstractMinecart previous = null;
		AbstractMinecart current = engine;

		while (current != null && seen.add(current.getUUID()) && train.size() < MAX_TRAIN_LENGTH) {
			train.add(current);
			AbstractMinecart next = nextLinkedMinecart(level, current, previous, seen);
			previous = current;
			current = next;
		}

		return train;
	}

	private static AbstractMinecart nextLinkedMinecart(
		final ServerLevel level, final AbstractMinecart current, final AbstractMinecart previous, final Set<UUID> seen
	) {
		return linkedMinecarts(level, (MinecartChainAccess) current).stream()
			.filter(linked -> previous == null || !linked.getUUID().equals(previous.getUUID()))
			.filter(linked -> !seen.contains(linked.getUUID()))
			.min(Comparator.comparingDouble(current::distanceToSqr))
			.orElse(null);
	}

	private static void guideFollower(final AbstractMinecart leader, final AbstractMinecart follower, final Vec3 fallbackDirection) {
		Vec3 toLeader = leader.position().subtract(follower.position()).horizontal();
		double distance = toLeader.length();
		if (distance <= 1.0E-4D) {
			return;
		}

		Vec3 leaderVelocity = leader.getDeltaMovement().horizontal();
		Vec3 localForward = leaderVelocity.lengthSqr() > 1.0E-5D ? leaderVelocity.normalize() : fallbackDirection;
		if (distance < MIN_LINK_DISTANCE) {
			Vec3 followerVelocity = follower.getDeltaMovement();
			Vec3 railFollowerVelocity = constrainToRail(follower, followerVelocity.horizontal().scale(FOLLOWER_OVERTAKE_BRAKE));
			double push = Mth.clamp((MIN_LINK_DISTANCE - distance) * MIN_DISTANCE_PUSH, 0.04D, MAX_LINK_IMPULSE);
			Vec3 pushAway = railPullVector(follower, toLeader.reverse(), push);
			Vec3 corrected = capHorizontalSpeed(railFollowerVelocity.add(pushAway), MAX_FOLLOWER_SPEED);
			follower.setDeltaMovement(corrected.x, followerVelocity.y, corrected.z);
			return;
		}

		if (localForward.lengthSqr() > 1.0E-5D && toLeader.dot(localForward) < -0.05D) {
			Vec3 slowed = constrainToRail(follower, follower.getDeltaMovement().horizontal().scale(FOLLOWER_OVERTAKE_BRAKE));
			Vec3 pullBack = railPullVector(follower, toLeader, MAX_LINK_IMPULSE);
			Vec3 corrected = capHorizontalSpeed(slowed.add(pullBack), MAX_FOLLOWER_SPEED);
			follower.setDeltaMovement(corrected.x, follower.getDeltaMovement().y, corrected.z);
			return;
		}

		Vec3 followerVelocity = follower.getDeltaMovement();
		Vec3 railFollowerVelocity = constrainToRail(follower, followerVelocity.horizontal());
		Vec3 railLeaderVelocity = constrainToRail(follower, leaderVelocity);
		Vec3 blendedVelocity = railFollowerVelocity.scale(1.0D - FOLLOWER_VELOCITY_BLEND)
			.add(railLeaderVelocity.scale(FOLLOWER_VELOCITY_BLEND));

		if (distance > LINK_DISTANCE) {
			double pull = Mth.clamp((distance - LINK_DISTANCE) * FOLLOWER_PULL, 0.0D, MAX_LINK_IMPULSE);
			blendedVelocity = blendedVelocity.add(railPullVector(follower, toLeader, pull));
		}

		blendedVelocity = constrainToRail(follower, blendedVelocity);
		blendedVelocity = capHorizontalSpeed(blendedVelocity, MAX_FOLLOWER_SPEED);
		follower.setDeltaMovement(blendedVelocity.x, followerVelocity.y, blendedVelocity.z);
	}

	private static void applyLinkConstraint(final AbstractMinecart first, final AbstractMinecart second) {
		Vec3 delta = second.position().subtract(first.position()).horizontal();
		double distance = delta.length();
		if (distance <= 1.0E-4D) {
			return;
		}

		if (distance > LINK_BREAK_DISTANCE) {
			((MinecartChainAccess) first).minecartChain$removeLink(second.getUUID());
			((MinecartChainAccess) second).minecartChain$removeLink(first.getUUID());
			return;
		}

		Vec3 direction = delta.scale(1.0D / distance);
		if (distance < MIN_LINK_DISTANCE) {
			pushMinecartsApart(first, second, direction, distance);
			return;
		}

		if (distance > MAX_LINK_DISTANCE) {
			clampLinkDistance(first, second, direction, distance);
			distance = MAX_LINK_DISTANCE;
		}

		double error = distance - LINK_DISTANCE;
		if (Math.abs(error) < 0.04D) {
			return;
		}

		double impulse = Mth.clamp(error * LINK_STIFFNESS, -MAX_LINK_IMPULSE, MAX_LINK_IMPULSE);
		Vec3 adjustment = direction.scale(impulse);
		Vec3 firstAdjustment = constrainToRail(first, adjustment);
		Vec3 secondAdjustment = constrainToRail(second, adjustment.reverse());
		first.setDeltaMovement(first.getDeltaMovement().add(firstAdjustment));
		second.setDeltaMovement(second.getDeltaMovement().add(secondAdjustment));
	}

	private static void pushMinecartsApart(final AbstractMinecart first, final AbstractMinecart second, final Vec3 direction, final double distance) {
		double deficit = MIN_LINK_DISTANCE - distance;
		Vec3 correction = direction.scale(deficit * 0.5D);
		Vec3 firstCorrection = constrainToRail(first, correction.reverse());
		Vec3 secondCorrection = constrainToRail(second, correction);
		first.setPos(first.getX() + firstCorrection.x, first.getY(), first.getZ() + firstCorrection.z);
		second.setPos(second.getX() + secondCorrection.x, second.getY(), second.getZ() + secondCorrection.z);

		double impulse = Mth.clamp(deficit * MIN_DISTANCE_PUSH, 0.04D, MAX_LINK_IMPULSE);
		Vec3 push = direction.scale(impulse);
		first.setDeltaMovement(first.getDeltaMovement().add(constrainToRail(first, push.reverse())));
		second.setDeltaMovement(second.getDeltaMovement().add(constrainToRail(second, push)));
	}

	private static void clampLinkDistance(final AbstractMinecart first, final AbstractMinecart second, final Vec3 direction, final double distance) {
		double excess = distance - MAX_LINK_DISTANCE;
		Vec3 correction = direction.scale(excess * 0.5D);
		Vec3 firstCorrection = constrainToRail(first, correction);
		Vec3 secondCorrection = constrainToRail(second, correction.reverse());
		first.setPos(first.getX() + firstCorrection.x, first.getY(), first.getZ() + firstCorrection.z);
		second.setPos(second.getX() + secondCorrection.x, second.getY(), second.getZ() + secondCorrection.z);

		Vec3 damping = direction.scale(MAX_LINK_IMPULSE);
		first.setDeltaMovement(first.getDeltaMovement().add(constrainToRail(first, damping)));
		second.setDeltaMovement(second.getDeltaMovement().add(constrainToRail(second, damping.reverse())));
	}

	private static Vec3 railPullVector(final AbstractMinecart minecart, final Vec3 desiredDirection, final double magnitude) {
		if (magnitude <= 0.0D || desiredDirection.horizontalDistanceSqr() <= 1.0E-8D) {
			return Vec3.ZERO;
		}

		Optional<Direction.Axis> railAxis = railAxis(minecart, desiredDirection);
		if (railAxis.isEmpty()) {
			return desiredDirection.horizontal().normalize().scale(magnitude);
		}

		Direction.Axis axis = railAxis.get();
		double signed = axis == Direction.Axis.X ? desiredDirection.x : desiredDirection.z;
		if (Math.abs(signed) <= 1.0E-8D) {
			return Vec3.ZERO;
		}

		double value = Math.signum(signed) * magnitude;
		return axis == Direction.Axis.X ? new Vec3(value, 0.0D, 0.0D) : new Vec3(0.0D, 0.0D, value);
	}

	private static Vec3 constrainToRail(final AbstractMinecart minecart, final Vec3 vector) {
		Vec3 horizontal = vector.horizontal();
		if (horizontal.lengthSqr() <= 1.0E-8D) {
			return Vec3.ZERO;
		}

		Optional<Direction.Axis> railAxis = railAxis(minecart, horizontal);
		if (railAxis.isEmpty()) {
			return horizontal;
		}

		return railAxis.get() == Direction.Axis.X ? new Vec3(horizontal.x, 0.0D, 0.0D) : new Vec3(0.0D, 0.0D, horizontal.z);
	}

	private static Vec3 capHorizontalSpeed(final Vec3 vector, final double maxSpeed) {
		double speedSqr = vector.horizontalDistanceSqr();
		if (speedSqr <= maxSpeed * maxSpeed) {
			return vector;
		}

		Vec3 horizontal = vector.horizontal().normalize().scale(maxSpeed);
		return new Vec3(horizontal.x, vector.y, horizontal.z);
	}

	private static Optional<Direction.Axis> railAxis(final AbstractMinecart minecart, final Vec3 desiredDirection) {
		if (!(minecart.level() instanceof ServerLevel serverLevel) || !minecart.isOnRails()) {
			return Optional.empty();
		}

		BlockPos railPos = minecart.getCurrentBlockPosOrRailBelow();
		BlockState railState = serverLevel.getBlockState(railPos);
		if (!BaseRailBlock.isRail(railState)) {
			railPos = railPos.below();
			railState = serverLevel.getBlockState(railPos);
		}

		if (!BaseRailBlock.isRail(railState) || !(railState.getBlock() instanceof BaseRailBlock railBlock)) {
			return Optional.empty();
		}

		RailShape shape = railState.getValue(railBlock.getShapeProperty());
		return Optional.of(axisForShape(shape, desiredDirection));
	}

	private static Direction.Axis axisForShape(final RailShape shape, final Vec3 desiredDirection) {
		return switch (shape) {
			case NORTH_SOUTH, ASCENDING_NORTH, ASCENDING_SOUTH -> Direction.Axis.Z;
			case EAST_WEST, ASCENDING_EAST, ASCENDING_WEST -> Direction.Axis.X;
			case SOUTH_EAST, SOUTH_WEST, NORTH_WEST, NORTH_EAST ->
				Math.abs(desiredDirection.x) >= Math.abs(desiredDirection.z) ? Direction.Axis.X : Direction.Axis.Z;
		};
	}
}
